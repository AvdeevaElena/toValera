import React from "react";
import style from "./notFound.module.css";

const NotFound = () => {
  return <div>Not Found</div>;
};

export default NotFound;
