export const MAIN_EMPTY = "/mainEmpty";
export const PATIENTS = "/patients";
export const REQUESTS = "/requests";
export const WISHES = "/wishes";
export const CHAMBERS = "/chambers";
export const DOCUMENTS = "/documents";
export const NEWS = "/news";
export const NEWS_EMPTY = "/newsEmpty";
export const SCHEDULE = "/chedule";
export const EMPLOYEES = "/employees";
export const ABOUT_US = "/about-us";
export const MAIN = "/";
export const NEWS_ROLE_READ = "/newsRoleRead";

